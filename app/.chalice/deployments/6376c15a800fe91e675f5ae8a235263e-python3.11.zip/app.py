import boto3
import json
import os
import urllib.request

from chalice import Chalice, Response


bills_table_name = os.getenv("BILLS_TABLE_NAME", "bills")
tariffs_table_name = os.getenv("tariffs_TABLE_NAME", "dealers_tariff")

app = Chalice(app_name="energy_consultant")

dynamodb = boto3.resource("dynamodb")

bills_table = dynamodb.Table(bills_table_name)

tariffs_table = dynamodb.Table(tariffs_table_name)


@app.route("/bills/{pod}/{year_month_from}")
def get_bill(pod, year_month_from):
    response = bills_table.get_item(
        Key={"pod": pod, "year_month_from": year_month_from}
    )

    return Response(
        body=response["Item"],
        status_code=200,
        headers={"Content-Type": "application/json"},
    )


@app.route("/bills/{pod}")
def list_bills(pod):
    response = bills_table.query(
        KeyConditionExpression="pod = :pod",
        ExpressionAttributeValues={":pod": pod},
    )

    # extract the items from the response
    items = response["Items"]

    return Response(
        body=items,
        status_code=200,
        headers={"Content-Type": "application/json"},
    )


@app.route("/bills/{pod}", methods=["POST"])
def put_bill(pod):
    request = app.current_request.json_body
    bills_table.put_item(
        Item={
            "pod": pod,
            "year_month_from": request["year_month_from"],
            "consumption": request["consumption"],
        }
    )

    Response(
        body={"status": "OK"},
        status_code=200,
        headers={"Content-Type": "application/json"},
    )


@app.route("/tariffs")
def list_tariffs():
    all_tariffs = []
    # Set the pagination parameters
    page_size = 100
    starting_token = None

    # Loop through the pages
    while True:
        # Set the pagination parameters for the current page
        page_params = {
            "Limit": page_size,
        }
        if starting_token:
            page_params["ExclusiveStartKey"] = starting_token

        # Scan the table for the current page
        response = tariffs_table.scan(**page_params)

        # Process the results
        items = response["Items"]
        all_tariffs.extend(items)

        # Check if there are more pages
        if "LastEvaluatedKey" in response:
            starting_token = response["LastEvaluatedKey"]
        else:
            break

    Response(
        body=all_tariffs,
        status_code=200,
        headers={"Content-Type": "application/json"},
    )


@app.lambda_function(name="bedrock-proxy")
def bedrock_proxy(event, context):
    print(event)
    path = event["apiPath"]
    http_method = event["httpMethod"]
    headers = event.get(
        "headers",
        {
            "accept": "*/*",
            "accept-language": "it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7",
            "content-type": "application/json",
        },
    )
    request_body = {
        param["name"]: param["value"]
        for param in event.get("requestBody", {})
        .get("content", {})
        .get("application/json", {})
        .get("properties", [])
    }
    parameters = {
        param["name"]: param["value"] for param in event.get("parameters", [])
    }
    url = os.getenv("API_GW_STAGE_URL") + path

    path_params = dict()
    query_params = dict()

    for key, value in parameters.items():
        if "{" + key + "}" in url:
            path_params[key] = value
        else:
            query_params[key] = value

    url = url.format(**path_params)

    print(url)

    if query_params:
        url += "?" + urllib.parse.urlencode(query_params)
    print(f"URL: {url}")
    req = urllib.request.Request(
        url,
        headers=headers,
        method=http_method,
        data=bytes(json.dumps(request_body), encoding="utf-8"),
    )

    resp = urllib.request.urlopen(req)
    body = resp.read()

    response_body = {"application/json": {"body": body.decode("utf-8")}}
    action_response = {
        "actionGroup": event["actionGroup"],
        "apiPath": event["apiPath"],
        "httpMethod": event["httpMethod"],
        "httpStatusCode": 200,
        "responseBody": response_body,
    }
    api_response = {"messageVersion": "1.0", "response": action_response}

    return api_response
