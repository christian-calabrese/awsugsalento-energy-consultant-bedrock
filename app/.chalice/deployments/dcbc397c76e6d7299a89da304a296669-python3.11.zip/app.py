import boto3
import os
import urllib.request

from chalice import Chalice, Response


bills_table_name = os.getenv("BILLS_TABLE_NAME", "bills")
suppliers_table_name = os.getenv("SUPPLIERS_TABLE_NAME", "suppliers")

app = Chalice(app_name="energy_consultant")

dynamodb = boto3.resource("dynamodb")

bills_table = dynamodb.Table(bills_table_name)

suppliers_table = dynamodb.Table(suppliers_table_name)


@app.route("/bills/{user_id}/{year_month}")
def get_bill(user_id, year_month):
    response = bills_table.get_item(Key={"user_id": user_id, "year_month": year_month})
    cost = float(response["Item"]["cost"])

    return Response(
        body={"user_id": user_id, "year_month": year_month, "cost": cost},
        status_code=200,
        headers={"Content-Type": "application/json"},
    )


@app.route("/bills/{user_id}")
def list_bills(user_id):
    response = bills_table.query(
        KeyConditionExpression="user_id = :user_id",
        ExpressionAttributeValues={":user_id": user_id},
    )

    # extract the items from the response
    items = response["Items"]

    return Response(
        body=items,
        status_code=200,
        headers={"Content-Type": "application/json"},
    )


@app.route("/bills/{user_id}", methods=["POST"])
def put_bill(user_id):
    request = app.current_request.json_body
    bills_table.put_item(
        Item={
            "user_id": user_id,
            "year_month": request["year_month"],
            "cost": request["cost"],
        }
    )

    Response(
        body={"status": "OK"},
        status_code=200,
        headers={"Content-Type": "application/json"},
    )


@app.lambda_function(name=f"{app.app_name}-bedrock-proxy")
def bedrock_proxy(event, context):
    print(event)
    path = event["apiPath"]
    http_method = event["httpMethod"]
    headers = event.get("headers", {})
    request_body = {
        param["name"]: param["value"]
        for param in event.get("requestBody", {})
        .get("content", {})
        .get("application/json", {})
        .get("properties", [])
    }
    query = {param["name"]: param["value"] for param in event.get("parameters", [])}
    url = os.getenv("API_GW_STAGE_URL") + path

    if query:
        url += "?" + urllib.parse.urlencode(query)
    print(f"URL: {url}")
    req = urllib.request.Request(
        url, headers=headers, method=http_method, data=request_body
    )

    resp = urllib.request.urlopen(req)
    body = resp.read()

    response_body = {"application/json": {"body": body.decode("utf-8")}}
    action_response = {
        "actionGroup": event["actionGroup"],
        "apiPath": event["apiPath"],
        "httpMethod": event["httpMethod"],
        "httpStatusCode": 200,
        "responseBody": response_body,
    }
    api_response = {"messageVersion": "1.0", "response": action_response}

    Response(
        body=api_response,
        status_code=200,
        headers={"Content-Type": "application/json"},
    )
